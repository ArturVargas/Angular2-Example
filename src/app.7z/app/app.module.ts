import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {NgForm} from '@angular/forms';


//Routes
import {APP_ROUTING} from './app.routes';



import { AppComponent } from './app.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { HomeComponent } from './components/home/home.component';
import { SecurityComponent } from './components/security/security.component';
import { CatalogosComponent } from './components/catalogos/catalogos.component';
import { ReportesComponent } from './components/reportes/reportes.component';
import {AlumnosComponent} from './components/catalogos/alumnos/alumnos.component';

//Services
import {AuthService} from './services/auth.service';
import {AuthGuardService} from './services/auth-guard.service';
import {FiltroService} from './services/filtro.service';
// import { AlumnosComponent } from './components/catalogos/alumnos/alumnos.component';
import { EditAlumnosComponent } from './components/catalogos/alumnos/edit-alumnos/edit-alumnos.component';
import { TutoresComponent } from './components/catalogos/tutores/tutores.component';
import { DireccionesComponent } from './components/catalogos/direcciones/direcciones.component';
import { RutaComponent } from './components/catalogos/ruta/ruta.component';
import { AutobusesComponent } from './components/catalogos/autobuses/autobuses.component';
import { NanasComponent } from './components/catalogos/nanas/nanas.component';
import { ConductoresComponent } from './components/catalogos/conductores/conductores.component';
import { EditAutobusesComponent } from './components/catalogos/autobuses/edit-autobuses/edit-autobuses.component';
import { EditConductoresComponent } from './components/catalogos/conductores/edit-conductores/edit-conductores.component';
import { EditDireccionesComponent } from './components/catalogos/direcciones/edit-direcciones/edit-direcciones.component';
import { EditNanasComponent } from './components/catalogos/nanas/edit-nanas/edit-nanas.component';
import { EditTutoresComponent } from './components/catalogos/tutores/edit-tutores/edit-tutores.component';
import { EditRutasComponent } from './components/catalogos/ruta/edit-rutas/edit-rutas.component';
import { ParadasComponent } from './components/catalogos/paradas/paradas.component';
import { EditParadasComponent } from './components/catalogos/paradas/edit-paradas/edit-paradas.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    HomeComponent,
    SecurityComponent,
    CatalogosComponent,
    ReportesComponent,
    AlumnosComponent,
    EditAlumnosComponent,
    TutoresComponent,
    DireccionesComponent,
    RutaComponent,
    AutobusesComponent,
    NanasComponent,
    ConductoresComponent,
    EditAutobusesComponent,
    EditConductoresComponent,
    EditDireccionesComponent,
    EditNanasComponent,
    EditTutoresComponent,
    EditRutasComponent,
    ParadasComponent,
    EditParadasComponent
  ],
  imports: [
    BrowserModule,
    APP_ROUTING,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [
    AuthService,
    AuthGuardService,
    FiltroService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
