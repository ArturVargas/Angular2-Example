import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-catalogos',
  templateUrl: './catalogos.component.html',
  styles: []
})
export class CatalogosComponent implements OnInit {



  constructor() {

  }

  ngOnInit() {
  }

}
