import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
    selector: 'app-edit-direcciones',
    templateUrl: './edit-direcciones.component.html',
    styles: [`.ng-valid.touched{ border: 1px solid red;}`]
})
export class EditDireccionesComponent {

    forma: FormGroup;
    direccion: Object = {
        idDireccion: "",
        noFamilia: "",
        calle: "",
        numeroExterior: "",
        numeroInterior: "",
        colonia: "",
        municipio: "",
        grupo: "",
        estado: "",
        codigoPostal: "",
        referencias: ""
    }
    constructor() {
        this.forma = new FormGroup({
            'idDireccion': new FormControl('', [Validators.required]),
            'noFamilia': new FormControl('', [Validators.required]),
            'numeroInterior': new FormControl('', []),
            'calle': new FormControl('', [Validators.required]),
            'numeroExterior': new FormControl('', [Validators.required]),
            'colonia': new FormControl('', [Validators.required]),
            'grupo': new FormControl('', [Validators.required]),
            'municipio': new FormControl('', [Validators.required]),

            'estado': new FormControl('', [Validators.required]),
            'codigoPostal': new FormControl('', [Validators.required]),
            'referencias': new FormControl('', [Validators.required])
        })
        this.forma.setValue(this.direccion);

    }

    guardarCambios() {
        console.log(this.forma.value);
        this.forma.reset({
            idDireccion: "",
            noFamilia: "",
            calle: "",
            numeroExterior: "",
            numeroInterior: "",
            colonia: "",
            municipio: "",
            grupo: "",
            estado: "",
            codigoPostal: "",
            referencias: ""
        });
    }
    // guardar(forma:NgForm){
    //   console.log("Formulario");
    //   console.log(forma);
    //   console.log(forma.value);
    //   console.log("Usuario", this.usuario);
    // }

}