import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {FiltroService, Conductor} from 'app/services/filtro.service';

@Component({
  selector: 'app-direcciones',
  templateUrl: './direcciones.component.html'
})
export class DireccionesComponent implements OnInit {

  direcciones:any[]=[];

  constructor(private _filtroService:FiltroService) { }

  ngOnInit() {
    this.direcciones = this._filtroService.getCatDirecciones();
    console.log(this.direcciones);
  }

 buscarDireccion(texto:string){
   console.log(texto);
 }
}
