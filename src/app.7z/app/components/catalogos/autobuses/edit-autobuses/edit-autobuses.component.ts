import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
    selector: 'app-edit-autobuses',
    templateUrl: './edit-autobuses.component.html',
    styles: [`.ng-valid.touched{ border: 1px solid red;}`]
})
export class EditAutobusesComponent {

    forma: FormGroup;
    autobus: Object = {
        noAutobus: "",
        nombreAutobus: "",
        placaAutobus: "",
        marca: "",
        modelo: "",
        anio: "",
        capacidad: ""
    }
    constructor() {
        this.forma = new FormGroup({
            'noAutobus': new FormControl('', [Validators.required]),
            'nombreAutobus': new FormControl('', [Validators.required]),
            'placaAutobus': new FormControl('', [Validators.required]),
            'marca': new FormControl('', [Validators.required]),
            'modelo': new FormControl('', [Validators.required]),
            'anio': new FormControl('', [Validators.required]),
            'capacidad': new FormControl('', [Validators.required])
        })
        this.forma.setValue(this.autobus);

    }

    guardarCambios() {
        console.log(this.forma.value);
        this.forma.reset({
            noAutobus: "",
            nombreAutobus: "",
            placaAutobus: "",
            marca: "",
            modelo: "",
            anio: "",
            capacidad: ""
        });
    }
    // guardar(forma:NgForm){
    //   console.log("Formulario");
    //   console.log(forma);
    //   console.log(forma.value);
    //   console.log("Usuario", this.usuario);
    // }

}