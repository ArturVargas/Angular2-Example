import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {FiltroService, Conductor} from 'app/services/filtro.service';

@Component({
  selector: 'app-autobuses',
  templateUrl: './autobuses.component.html'
})
export class AutobusesComponent implements OnInit {

  autobuses:any[]=[];

  constructor(private _filtroService:FiltroService) { }

  ngOnInit() {
    this.autobuses = this._filtroService.getCatAutobuses();
    console.log(this.autobuses);
  }

 buscarAutobus(texto:string){
   console.log(texto);
 }   

}
