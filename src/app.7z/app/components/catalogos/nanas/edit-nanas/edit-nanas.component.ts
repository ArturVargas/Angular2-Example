import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
    selector: 'app-edit-nanas',
    templateUrl: './edit-nanas.component.html',
    styles: [`.ng-valid.touched{ border: 1px solid red;}`]
})
export class EditNanasComponent {

    forma: FormGroup;
    nana: Object = {
        idNana: "",
        apellidoPaternoNana: "",
        apellidoMaternoNana: "",
        nombreNana: "",
        direccionNana: "",
        telefonoNana: ""
    }
    constructor() {
        this.forma = new FormGroup({
            'idNana': new FormControl('', [Validators.required]),
            'apellidoPaternoNana': new FormControl('', [Validators.required]),
            'apellidoMaternoNana': new FormControl('', []),
            'nombreNana': new FormControl('', [Validators.required]),
            'direccionNana': new FormControl('', [Validators.required]),
            'telefonoNana': new FormControl('', [Validators.required])
        })
        this.forma.setValue(this.nana);

    }

    guardarCambios() {
        console.log(this.forma.value);
        this.forma.reset({
            idNana: "",
            apellidoPaternoNana: "",
            apellidoMaternoNana: "",
            nombreNana: "",
            direccionNana: "",
            telefonoNana: ""
        });
    }
    // guardar(forma:NgForm){
    //   console.log("Formulario");
    //   console.log(forma);
    //   console.log(forma.value);
    //   console.log("Usuario", this.usuario);
    // }

}