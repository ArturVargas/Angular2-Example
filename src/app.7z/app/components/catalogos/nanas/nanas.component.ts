import { Component, OnInit } from '@angular/core';

import { ActivatedRoute } from '@angular/router';
import { FiltroService, Alumno } from 'app/services/filtro.service';

@Component({
  selector: 'app-nanas',
  templateUrl: './nanas.component.html',
  styles: []
})
export class NanasComponent implements OnInit {

    nanas: any[] = [];

    constructor(private _filtroService: FiltroService) { }

    ngOnInit() {
        this.nanas = this._filtroService.getCatNanas();
        //console.log(this.alumnos);
    }

    buscarNana(texto: string) {
        var datos = texto.split(';');


        this.nanas = this._filtroService.buscarNana(datos[0]);

    }


}
