import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {FiltroService, Conductor} from 'app/services/filtro.service';

@Component({
  selector: 'app-conductores',
  templateUrl: './conductores.component.html'
})
export class ConductoresComponent implements OnInit {

  conductores:any[]=[];

  constructor(private _filtroService:FiltroService) { }

  ngOnInit() {
    this.conductores = this._filtroService.getCatConductores();
    console.log(this.conductores);
  }

 buscarConductor(texto:string){
   console.log(texto);
 }
}
