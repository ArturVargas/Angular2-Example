import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
    selector: 'app-edit-conductores',
    templateUrl: './edit-conductores.component.html',
    styles: [`.ng-valid.touched{ border: 1px solid red;}`]
})
export class EditConductoresComponent {

    forma: FormGroup;
    conductor: Object = {
        idConductor: "",
        apellidoPaternoConductor: "",
        apellidoMaternoConductor: "",
        nombreConductor: "",
        direccionConductor: "",
        telefonoConductor: ""
    }
    constructor() {
        this.forma = new FormGroup({
            'idConductor': new FormControl('', [Validators.required]),
            'apellidoPaternoConductor': new FormControl('', [Validators.required]),
            'apellidoMaternoConductor': new FormControl('', [Validators.required]),
            'nombreConductor': new FormControl('', [Validators.required]),
            'direccionConductor': new FormControl('', [Validators.required]),
            'telefonoConductor': new FormControl('', [Validators.required])
        })
        this.forma.setValue(this.conductor);

    }

    guardarCambios() {
        console.log(this.forma.value);
        this.forma.reset({
            idConductor: "",
            apellidoPaternoConductor: "",
            apellidoMaternoConductor: "",
            nombreConductor: "",
            direccionConductor: "",
            telefonoConductor: ""
        });
    }
    // guardar(forma:NgForm){
    //   console.log("Formulario");
    //   console.log(forma);
    //   console.log(forma.value);
    //   console.log("Usuario", this.usuario);
    // }

}