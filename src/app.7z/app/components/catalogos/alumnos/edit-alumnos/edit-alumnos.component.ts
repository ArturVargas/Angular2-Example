import { Component, OnInit } from '@angular/core';
import {NgForm} from '@angular/forms';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import {FormGroup, FormControl, Validators} from '@angular/forms';

@Component({
  selector: 'app-edit-alumnos',
  templateUrl: './edit-alumnos.component.html',
  styles: [`.ng-valid.touched{ border: 1px solid red;}`]
})
export class EditAlumnosComponent {

  forma:FormGroup;
  alumno: Object = {
    noFamilia:"",
    apellidoPaternoAlumno:"",
    apellidoMaternoAlumno: "",
    nombreAlumno:"",
    nivelEscolar: "",
    grado: "",
    grupo: "",
    genero: "",
    emailAlumno: "",
    fechaNacimiento:"",
    telefonoLocal: "",
    telefonoMovil: "",
    cicloEscolar:""
  }
  constructor() {
    this.forma = new FormGroup({
      'nombreAlumno': new FormControl('', [Validators.required]),
      'apellidoPaternoAlumno': new FormControl('', [Validators.required]),
      'apellidoMaternoAlumno': new FormControl('', []),      
      'emailAlumno': new FormControl('', [Validators.required,
          Validators.pattern("[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$")]),
      'noFamilia': new FormControl('', [Validators.required]),
      'nivelEscolar': new FormControl('', [Validators.required]),
      'grado': new FormControl('', [Validators.required]),
      'grupo': new FormControl('', [Validators.required]),
      'genero': new FormControl('', [Validators.required]),
      'fechaNacimiento': new FormControl('', [Validators.required]),      
      'telefonoLocal': new FormControl('', [Validators.required]),
      'telefonoMovil': new FormControl('', [Validators.required]),
      'cicloEscolar': new FormControl('', [Validators.required])
   })
   this.forma.setValue(this.alumno);

 }

 guardarCambios(){
   console.log(this.forma.value);
   this.forma.reset({
       noFamilia: "",
       apellidoPaternoAlumno: "",
       apellidoMaternoAlumno: "",
       nombreAlumno: "",
       nivelEscolar: "",
       grado: "",
       grupo: "",
       genero: "",
       emailAlumno: "",
       fechaNacimiento: "",
       telefonoLocal: "",
       telefonoMovil: "",
       cicloEscolar: ""
   });
 }
  // guardar(forma:NgForm){
  //   console.log("Formulario");
  //   console.log(forma);
  //   console.log(forma.value);
  //   console.log("Usuario", this.usuario);
  // }

}
