import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FiltroService, Alumno } from 'app/services/filtro.service';
//import {CatalogosService} from '../../services/catalogos.service';

@Component({
    selector: 'app-alumnos',
    templateUrl: './alumnos.component.html'
})
export class AlumnosComponent implements OnInit {

    alumnos: any[] = [];

    constructor(private _filtroService: FiltroService) { }

    ngOnInit() {
        //this.alumnos = this._filtroService.getCatAlumnos();
        //console.log(this.alumnos);
    }

    buscarAlumno(texto: string) {
        var datos = texto.split(';');


        this.alumnos = this._filtroService.buscarAlumno(datos[0], datos[1], datos[2]);

    }


}
