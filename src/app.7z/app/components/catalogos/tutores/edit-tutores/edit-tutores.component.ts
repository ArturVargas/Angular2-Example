import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
    selector: 'app-edit-tutores',
    templateUrl: './edit-tutores.component.html',
    styles: [`.ng-valid.touched{ border: 1px solid red;}`]
})
export class EditTutoresComponent {

    forma: FormGroup;
    tutor: Object = {
        idTutor: "",
        apellidoPaternoTutor: "",
        apellidoMaternoTutor: "",
        nombreTutor: "",
        telefonoLocalTutor: "",
        noFamilia: "",
        telefonoMovilTutor: "",
        genero: "",
        correoFamilia: "",
        registradoAplicacion: ""
    }
    constructor() {
        this.forma = new FormGroup({
            'nombreTutor': new FormControl('', [Validators.required]),
            'apellidoPaternoTutor': new FormControl('', [Validators.required]),
            'apellidoMaternoTutor': new FormControl('', []),
            'correoFamilia': new FormControl('', [Validators.required,
            Validators.pattern("[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$")]),
            'noFamilia': new FormControl('', [Validators.required]),
            'registradoAplicacion': new FormControl('', [Validators.required]),
            'genero': new FormControl('', [Validators.required]),

            'telefonoLocalTutor': new FormControl('', [Validators.required]),
            'telefonoMovilTutor': new FormControl('', [Validators.required]),
            'idTutor': new FormControl('', [Validators.required])
        })
        this.forma.setValue(this.tutor);

    }

    guardarCambios() {
        console.log(this.forma.value);
        this.forma.reset({
            idTutor: "",
            apellidoPaternoTutor: "",
            apellidoMaternoTutor: "",
            nombreTutor: "",
            telefonoLocalTutor: "",
            noFamilia: "",
            telefonoMovilTutor: "",
            genero: "",
            correoFamilia: "",
            registradoAplicacion: ""
        });
    }
    // guardar(forma:NgForm){
    //   console.log("Formulario");
    //   console.log(forma);
    //   console.log(forma.value);
    //   console.log("Usuario", this.usuario);
    // }

}