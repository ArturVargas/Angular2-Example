import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FiltroService, Alumno } from 'app/services/filtro.service';

@Component({
  selector: 'app-tutores',
  templateUrl: './tutores.component.html',
  styles: []
})
export class TutoresComponent implements OnInit {

    tutores: any[] = [];

    constructor(private _filtroService: FiltroService) { }

    ngOnInit() {
        this.tutores = this._filtroService.getCatTutores();
        //console.log(this.alumnos);
    }

    buscarTutor(texto: string) {
        var datos = texto.split(';');


        this.tutores = this._filtroService.buscarAlumno(datos[0], datos[1], datos[2]);

    }


}
